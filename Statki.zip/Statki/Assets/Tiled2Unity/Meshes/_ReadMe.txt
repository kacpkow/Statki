Meshes directory

Tiled2Unity scripts will create meshes here. These meshes are packed into the 
prefab objects that represent your Tiled Map Editor maps.