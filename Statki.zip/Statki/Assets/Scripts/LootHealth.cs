﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LootHealth : MonoBehaviour {

	public int amount;
	void Start(){
		
	}

	public void UpdateAmount(int newAmount){
		amount = newAmount;
	}
}
